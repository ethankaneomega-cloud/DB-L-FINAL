<!-- Author: Abinash das -->
<?php 
require_once('./config.php');
redirect('admin');
?>
 